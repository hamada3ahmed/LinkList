# LinkList

[Visit Now](https://jigar-sable.github.io/LinkList) 🚀

[![PRs Welcome](https://img.shields.io/badge/PRs-Welcome-brightgreen.svg?style=flat&logo=github)](https://github.com/jigar-sable/LinkList)&nbsp;
![contributions welcome](https://img.shields.io/static/v1.svg?label=Contributions&message=Welcome&color=brightgreen&style=flat&logo=github)&nbsp;
[![javascript-projects](https://img.shields.io/website-up-down-green-red/http/shields.io.svg?color=blue)](https://jigar-sable.github.io/LinkList/)&nbsp;
[![repo-size](https://img.shields.io/github/repo-size/jigar-sable/JavaScript-Projects)](https://github.com/jigar-sable/LinkList)




## Overview

All major profile links in a single website.
Made with basic HTML and CSS.

## Tech Stack
[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/jigar-sable/LinkList/search?l=html)&nbsp;
[![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)](https://github.com/jigar-sable/LinkList/search?l=css)&nbsp;

## Sneak Peek of Web Page 🙈 :
![linklist](https://user-images.githubusercontent.com/64949957/124396066-1b828880-dd25-11eb-9ee8-53de21d9faac.PNG)



<h2>📬 Contact</h2>

If you want to contact me, you can reach me through below handles.

&nbsp;&nbsp;<a href="https://www.linkedin.com/in/jigar-sable/"><img src="https://www.felberpr.com/wp-content/uploads/linkedin-logo.png" width="30"></img></a>

© 2021 Jigar Sable


[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com)
